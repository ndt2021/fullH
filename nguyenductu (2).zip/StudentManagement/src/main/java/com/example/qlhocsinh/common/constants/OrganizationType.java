package com.example.qlhocsinh.common.constants;

public enum OrganizationType {
SCOOL,CLASS
}
