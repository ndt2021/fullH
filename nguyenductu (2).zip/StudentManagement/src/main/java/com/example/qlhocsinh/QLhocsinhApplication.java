package com.example.qlhocsinh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QLhocsinhApplication {

    public static void main(String[] args) {
        SpringApplication.run(QLhocsinhApplication.class, args);
    }

}
