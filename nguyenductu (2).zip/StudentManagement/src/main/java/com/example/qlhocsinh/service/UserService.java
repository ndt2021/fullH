package com.example.qlhocsinh.service;

import com.example.qlhocsinh.models.User;
import com.example.qlhocsinh.reponsivetory.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getUserById(String userId) {
        return userRepository.findById(UUID.fromString(userId)).orElse(null);
    }

    public User createUser(User user) {
        // Thực hiện các kiểm tra hoặc logic nghiệp vụ trước khi lưu vào cơ sở dữ liệu (nếu cần)
        return userRepository.save(user);
    }

    public User updateUser(String userId, User user) {
        // Kiểm tra xem user có tồn tại không trước khi cập nhật
        User existingUser = userRepository.findById(UUID.fromString(userId)).orElse(null);
        if (existingUser != null) {
            // Thực hiện cập nhật dữ liệu
            existingUser.setName(user.getName());
            // Các trường khác có thể được cập nhật tương tự
            userRepository.save(existingUser);
        }
        return existingUser;
    }

    public void deleteUser(String userId) {
        // Kiểm tra xem user có tồn tại không trước khi xóa
        User existingUser = userRepository.findById(UUID.fromString(userId)).orElse(null);
        if (existingUser != null) {
            userRepository.delete(existingUser);
        }
    }
}
